//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Keyb.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_KEYB_DIALOG                 102
#define IDR_MAINFRAME                   128
//#define IDB_LOGO                        131
#define IDR_MENU                        134
//#define IDB_CODEPROJECT                 135
#define IDI_PLAY                        136
#define IDI_STOP                        139
#define IDI_RECORD                      140

#define IDC_MESSAGES_LIST               1005
#define IDC_INPUT_PORTS                 1006
#define IDC_OUTPUT_PORTS                1007
#define IDC_BUTTON_EXPAND               1008
#define IDC_INSTRUMENTS                 1010
#define IDC_REC                         1014
#define IDC_STOP                        1015
#define IDC_PLAY                        1016
#define IDC_CLEAR                       1017
#define IDC_MEMPROG                     1018
#define IDC_IMAGE                       1019
#define IDC_NOTE_RANGE                  1020
#define IDC_STATIC_URL                  1021
#define IDC_IMAGELOGO                   1022
#define IDC_BUTTON1                     1026

// Used by P5BendDemo.rc
//
#define IDC_STATUSMSG                   1027
#define IDC_THUMB                       1028
#define IDC_INDEX                       1029
#define IDC_PINKY                       1030
#define IDC_MIDDLE                      1031
#define IDC_RING                        1032

//#define IDC_INDEXSLIDER                 1034

#define IDC_THUMBCLICKSTATE             1033
#define IDC_INDEXCLICKSTATE             1034
#define IDC_MIDDLECLICKSTATE            1035
#define IDC_RINGCLICKSTATE              1036
#define IDC_PINKYCLICKSTATE             1037
/*
#define IDC_THUMBSLIDER                 1040
#define IDC_MIDDLESLIDER                1041
#define IDC_RINGSLIDER                  1042
#define IDC_PINKYSLIDER                 1043
*/
#define IDC_THUMBEDGE                   1038
#define IDC_INDEXEDGE                   1039
#define IDC_MIDDLEEDGE                  1040
#define IDC_RINGEDGE                    1041
#define IDC_PINKYEDGE                   1042

#define IDR_HELP                        32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
