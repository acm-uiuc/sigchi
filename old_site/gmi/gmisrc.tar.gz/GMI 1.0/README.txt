You may want the DirectX 9 SDK and P5 SDK; they are required to compile the project.
Also, it'll be easiest to get it working with Visual Studio 6. In VS, you need to setup the P5DLL and DirectMidi includes.

The GMI is protected by the BSD license.
Please see LICENSE.txt if you plan to redistribute any modification of this program. If you plan to redstribute for profit especially, you must first gain explicit permission. You may contact sigchi@uiuc.edu.

Have fun!
 - Joshua Eric Benjamin
	imagine@jbenjamin.org